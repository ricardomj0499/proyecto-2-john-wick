import unittest
import time
from simulated_annealing import optimizar
from dominio_tsp import DominioTSP


class PruebaSimulatedAnnealing(unittest.TestCase):

    def test_optimizar(self):
        dominio = DominioTSP('datos/ciudades_cr_pruebas.csv', 'Alajuela')
        sol = optimizar(dominio)
        self.assertTrue(dominio.validar(sol))


#Lo siguiente son pruebas para saber que el codigo esta bien
"""
dominio=DominioTSP('datos/ciudades_cr.csv', 'Alajuela')

#print(dominio.generar())
#sol=dominio.generar()
#print(dominio.texto(sol))
#print(dominio.fcosto(sol))

tiempo_ini = time.time()
sol = optimizar(dominio)
print(sol)
tiempo_fin = time.time()
t=tiempo_fin-tiempo_ini
t=t/60
print("Duracion: "+str(t))

#a=dominio.generar()
#b=dominio.pasar_de_numero_texto(a)

"""
