
import math  
import random
import time
"""
casas=[["km","B","F","A","J"],
		["B", 0 , 1,  8,  9 ],
		["F", 7,  0,  1,  10],
		["A", 8,  4,  0,  1],
		["J", 1, 10, 15,   0]]
		
casas2=[["km","B","F","A","J","D","M","R","Y","X"],
		["B",  0 , 7,  8,  9,  2 ,23 ,12 ,12,  4 ],
		["F",  7,  0,  4, 10,  3, 66,  3,  8 , 6],
		["A",  8,  4,  0, 15,  2,  7,  1,  5 , 9],
		["J",  9, 10, 15,  0,  1, 23, 19, 10 , 5],
		["D",  4, 56,  7,  1,  0,  3, 24, 15 , 5],
		["M",  1, 26,  4,  4,  2,  0, 12, 16 , 6],
		["R",  5, 16,  6,  1,  5,  3,  0, 15 , 9],
		["Y",  9, 1,   1,  1,  1,  3,  1,  0 ,10],
		["X", 56,12,   3, 45, 22,  1,  7,  9,  5]]
		
casas2=[["km","A","B","C","D","E","F","G","H","I","J","K"],
		["A",  0 , 7,  1,  9,  2 ,23 ,12 ,12 , 4,  6, 54 ],
		["B",  1,  0,  4, 10,  3, 66,  3,  8 , 6,  8,  5 ],
		["C",  8,  4,  0,  1,  2,  7, 11,  5 , 9,  3,  9 ],
		["D",  9, 10, 15,  0,  1, 23, 19, 10 , 5, 12, 34 ],
		["E",  4, 56,  7, 11,  0,  1, 24, 15 , 5, 12, 34 ],
		["F", 11, 26,  4,  4,  2,  0,  1, 16 , 6,123, 23 ],
		["G",  5, 16,  6,  1,  5,  3,  0,  1 , 9,323, 44 ],
		["H",  9, 11, 11, 11, 11,  3, 11,  0 , 1,543, 44],
		["I", 56, 12,  6, 45, 52,  4,  7,  9 , 0,  1, 21],
		["J", 56, 14,  3, 85, 12,  4,  7,  5 , 3,  0, 1 ],
		["K", 56, 12,  5, 45, 22,  4,  7,  9 , 5, 53, 0]]
		
casas3=[["km","A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q"],
		["A",  0 , 7,  1,  9,  2 ,23 ,12 ,11 ,23, 45, 12, 23, 22, 45, 78,123,  9 ],
		["B",  1 , 0,  8,  9,  2 ,23 ,12 ,12 ,23, 45, 12, 23, 22, 45, 78,113, 56 ],
		["C",  2 , 7,  0,  1,  2 ,23 ,12 ,12 ,23, 45, 12, 23, 22, 45, 78,103, 11 ],
		["D",  45, 1,  8,  0,  1 ,23 ,12 ,12 ,23, 45, 12, 23, 22, 45, 78,164, 56 ],
		["E",  9 , 7,  8,  9,  0 , 1 ,12 ,12 ,23, 45, 12, 23,  1, 45, 78,173, 56 ],
		["F",  8 , 7,  8,  9,  2 ,0 ,  1 ,12 ,23, 45, 12, 23, 22, 45, 78,  1, 56 ],
		["G",  7 , 7,  8,  9,  2 ,23 , 0 , 1 ,23, 45, 12, 23, 22, 45,  1,173, 56 ],
		["H",  6 , 7,  8,  9,  2 ,23 , 1 , 0 , 1, 45, 12, 23, 22, 45, 78,163, 56 ],
		["I",  7 , 7,  8,  9,  2 ,23 ,12 ,12 , 0,  1, 12,  1, 22, 45, 78,153, 56 ],
		["J",  7 ,34,  8,  1,  2 ,23 ,12 ,12 ,23,  0,  1 , 23, 22, 45, 78,123, 56 ],
		["K",  7 , 7,  8,  9,  2 ,23 ,12 ,12 ,23,  1,  0,  1, 22, 45, 78,128, 56 ],
		["L",  7 , 7,  8,  9,  2 ,23 ,12 ,12 ,23, 45,  1,  0,  1, 45, 78,123, 56 ],
		["M",  7 , 7,  8,  9,  2 , 1 ,12 ,12 ,23, 45, 12, 23,  0,  1, 78,123, 56 ],
		["N",  7 , 7,  8,  9,  2 ,23 ,12 ,12 , 1, 45, 12, 23, 22,  0,  1,133, 56 ],
		["O",  7 , 7,  1,  9,  2 ,23 ,12 ,12 ,23, 45, 12, 23, 22, 45,  0,  1, 56 ],
		["P",  8 , 7,  8,  9,  2 ,23 ,12 ,12 ,23, 45, 12, 23, 22,  1, 78,  0,  1 ],
		["Q",  8 , 1,  8,  9,  11 ,23 ,12 ,12 ,23, 45, 12, 23, 22, 45, 78,186,  0 ]]
		


	

"""
#def optimizar(dominio, temperatura=10e26,tasa_enfriamiento=0.999999)
#Con las anteriores entradas el algoritmo funciona muy bien
 	
def optimizar(dominio, temperatura=10e32,tasa_enfriamiento=0.95):
    """Algoritmo de optimización estocástica simulated annealing.

    Entradas:
    dominio (Dominio)
        Un objeto que modela el dominio del problema que se quiere aproximar.

    temperatura (float/int)
        Temperatura inicial del algoritmo, se recomienda un número alto

    tasa_enfriamiento (float)
        Porcentaje de enfriamiento de la temperatura durante cada iteración, el valor
        por defecto es 0.95, lo que indica una tasa de enfriamiento del 5%.

    Salidas:
        (estructura de datos) Estructura de datos según el dominio, que representa una
        aproximación a la mejor solución al problema.
    """
    sol=dominio.generar()
    costo=dominio.fcosto(sol)
    #print(costo)
    while(temperatura>0.01):
        sol_prima=dominio.vecino(sol)
        costo_prima=dominio.fcosto(sol_prima)
        #print("costo vecino: "+str(costo_prima))
        p=math.exp(-abs(costo_prima-costo)/temperatura)
        p_azar= random.uniform(0,1)
		#print("uno: "+str(costo)+".....dos: "+str(costo_prima))
        if(costo_prima<=costo or p_azar<p):
            sol=sol_prima
            costo=costo_prima	
        print(costo)
        temperatura=temperatura*tasa_enfriamiento
        #print(temperatura)
    return sol


"""
tiempo_ini = time.time()
a=optimizar(casas3,10e28,0.999999)
tiempo_fin = time.time()

t=tiempo_fin-tiempo_ini
t=t/60
print(str(a)+str(generar_costo_por_solucion(casas3,a)))
print("Tiempo: "+str(t))
"""
