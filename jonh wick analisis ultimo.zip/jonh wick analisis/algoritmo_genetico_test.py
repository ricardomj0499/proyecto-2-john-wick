import unittest
import time

from algoritmo_genetico import optimizar
from dominio_ag_tsp import DominioAGTSP

class PruebaAlgoritmoGenetico(unittest.TestCase):

    def test_optimizar(self):
        dominio = DominioAGTSP('datos/ciudades_cr_pruebas.csv', 'Alajuela')
        sol = optimizar(dominio, 100, 0.5, 0.6, 10000)
        self.assertTrue(dominio.validar(sol))


#pruebas algoritmo genetico

"""
dominio=DominioAGTSP('datos/ciudades_cr.csv', 'Alajuela')



tiempo_ini = time.time()
sol = optimizar(dominio, 1000, 0.1, 0.1, 100000)
tiempo_fin = time.time()
t=tiempo_fin-tiempo_ini
t=t/60
print("Duracion: "+str(t))

"""


