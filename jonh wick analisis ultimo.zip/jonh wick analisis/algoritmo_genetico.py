import math
import random
def optimizar(dominio, tam_pobl, porc_elite, prob_mut, reps):
    """Algoritmo genético para optimización estocástica.

    Entradas:
    dominio (DominioAG)
        Un objeto que modela el dominio del problema que se quiere aproximar.
    
    tam_pobl (int)
        Tamaño de la población.
    
    porc_elite (float)
        Porcentaje de la población que se tomará como elite.
    
    prob_mut (float)
        Probabilidad de mutación, debe estar en el rango [0, 1]
    
    reps (int)
        Número de iteraciones a ejecutar.

    Salidas:
        (estructura de datos) Estructura de datos según el dominio, que representa una
        aproximación a la mejor solución al problema.
    """
    pobl=dominio.generar_n(tam_pobl)
    aptitud_de_poblacion=[]
    while(reps>0):
        for i in(pobl):
            aptitud_de_poblacion.append(dominio.fcosto(i))
        aptitud_de_poblacion, pobl = zip(*sorted(zip(aptitud_de_poblacion, pobl)))
        aptitud_de_poblacion, pobl = (list(t) for t in zip(*sorted(zip(aptitud_de_poblacion, pobl))))
        
        
        print("Menor: "+str(aptitud_de_poblacion[0]))
        
        num_padres=math.floor((len(aptitud_de_poblacion)*porc_elite))
        num_hijos=(len(aptitud_de_poblacion)-num_padres)
        sig_gen=pobl[0:num_padres]
        
        #print("Buena")
        #for i in sig_gen:
          #  if(len(i)!=16):
           #     print("error en sig_gen")
        decendencia=[]
        while(num_hijos>0):
            #print(sig_gen)
            
            padre_a=random.choice(sig_gen)
            padre_b=random.choice(sig_gen)
            a=padre_a
            b=padre_b
            #print("Padre a: "+str(padre_a))
            #print("Padre b: "+str(padre_b))
            hijo=dominio.cruzar(padre_a,padre_b)
            #print(hijo)
       
            p=random.uniform(0,1)
            if(p<=prob_mut):
                hijo=dominio.mutar(hijo)
            #print(str(1)+str(decendencia))
            decendencia+=[hijo]
            #print("")
            #print(str(2)+str(decendencia)
            num_hijos-=1
        
        pobl=sig_gen+decendencia
        #print(pobl)
        aptitud_de_poblacion=[]
        #print(reps)
        reps-=1
		
	
	#dominio.ordenar(pobl,llave=aptitud)
			
    # Pendiente: implementar este método
    #pass


